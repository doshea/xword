window.App = window.App || {};
App.cable = ActionCable.createConsumer();
